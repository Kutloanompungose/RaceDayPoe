using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Authorize]
[Tags("Users")]
public class UsersController(AppDbContext db) : ControllerBase
{
    /// <summary>View your own profile (Organiser or Participant).</summary>
    /// <response code="200">Returns your profile.</response>
    /// <response code="401">Not logged in.</response>
    [HttpGet("/api/users/me")]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetMe()
    {
        var user = await db.Users.FindAsync(User.GetUserId());
        return user is null ? NotFound() : Ok(UserDto.From(user));
    }

    /// <summary>Update your own profile details (Organiser or Participant).</summary>
    /// <remarks>Expects fullName (required) and phone (optional). Email and role cannot be changed here.</remarks>
    /// <response code="200">Returns the updated profile.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    [HttpPut("/api/users/me")]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UpdateMe(UpdateProfileRequest req)
    {
        var user = await db.Users.FindAsync(User.GetUserId());
        if (user is null) return NotFound();

        user.FullName = req.FullName.Trim();
        user.Phone = req.Phone?.Trim();
        await db.SaveChangesAsync();
        return Ok(UserDto.From(user));
    }

    /// <summary>Upload (or replace) your profile picture. Stored in Azure Blob Storage.</summary>
    /// <remarks>Send multipart/form-data with a single file field named "file" (JPG, PNG, WEBP or GIF, max 5 MB).</remarks>
    /// <response code="200">Picture stored. Returns your profile including profilePictureUrl.</response>
    /// <response code="400">Missing, oversized or unsupported file.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="503">Blob Storage is not configured or could not be reached.</response>
    [HttpPost("/api/users/me/picture")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> UploadPicture(IFormFile file,
        [FromServices] IBlobStorageService blobs, CancellationToken ct)
    {
        var user = await db.Users.FindAsync(new object[] { User.GetUserId() }, ct);
        if (user is null) return NotFound();

        if (ImageRules.Validate(file) is { } invalid)
            return Problem(detail: invalid, statusCode: StatusCodes.Status400BadRequest);

        try
        {
            user.ProfilePictureUrl = await blobs.UploadImageAsync(file, $"users/{user.UserID}", ct);
        }
        catch (BlobStorageNotConfiguredException)
        {
            return Problem(detail: "Image storage is not configured on the server.", statusCode: StatusCodes.Status503ServiceUnavailable);
        }
        catch (Azure.RequestFailedException)
        {
            return Problem(detail: "The image could not be saved to cloud storage. Please try again.", statusCode: StatusCodes.Status503ServiceUnavailable);
        }

        await db.SaveChangesAsync(ct);
        return Ok(UserDto.From(user));
    }
}
