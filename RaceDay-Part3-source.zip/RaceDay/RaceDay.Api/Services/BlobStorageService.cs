using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDay.Api.Services;

/// <summary>Stores uploaded images in Azure Blob Storage and returns their public URL.</summary>
public interface IBlobStorageService
{
    /// <param name="file">The (already validated) image.</param>
    /// <param name="folder">Virtual folder inside the container, e.g. "events/12" or "users/5".</param>
    /// <param name="ct">Cancellation token.</param>
    /// <returns>The public URL of the stored blob.</returns>
    Task<string> UploadImageAsync(IFormFile file, string folder, CancellationToken ct = default);
}

/// <summary>Thrown when no Azure Blob Storage connection string has been configured.</summary>
public class BlobStorageNotConfiguredException()
    : Exception("Azure Blob Storage is not configured. Set AzureBlob:ConnectionString.");

/// <summary>Rules every uploaded image must satisfy before it is sent to Blob Storage.</summary>
public static class ImageRules
{
    public const long MaxBytes = 5 * 1024 * 1024; // 5 MB

    public static readonly Dictionary<string, string> ContentTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        [".jpg"] = "image/jpeg",
        [".jpeg"] = "image/jpeg",
        [".png"] = "image/png",
        [".webp"] = "image/webp",
        [".gif"] = "image/gif"
    };

    /// <summary>Returns an error message, or null when the file is acceptable.</summary>
    public static string? Validate(IFormFile? file)
    {
        if (file is null || file.Length == 0)
            return "Please choose an image file to upload.";
        if (file.Length > MaxBytes)
            return "The image is too large. The maximum size is 5 MB.";

        var ext = Path.GetExtension(file.FileName);
        if (string.IsNullOrEmpty(ext) || !ContentTypes.ContainsKey(ext))
            return "Only JPG, PNG, WEBP or GIF images are allowed.";

        return null;
    }
}

public class BlobStorageService(IConfiguration config) : IBlobStorageService
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private BlobContainerClient? _container;

    public async Task<string> UploadImageAsync(IFormFile file, string folder, CancellationToken ct = default)
    {
        var container = await GetContainerAsync(ct);

        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        var blobName = $"{folder.Trim('/')}/{Guid.NewGuid():N}{ext}";
        var blob = container.GetBlobClient(blobName);

        await using var stream = file.OpenReadStream();
        await blob.UploadAsync(stream, new BlobUploadOptions
        {
            HttpHeaders = new BlobHttpHeaders { ContentType = ImageRules.ContentTypes[ext] }
        }, ct);

        // PublicBaseUrl lets local emulators (Azurite) expose a browser-friendly address.
        var publicBase = config["AzureBlob:PublicBaseUrl"];
        return string.IsNullOrWhiteSpace(publicBase)
            ? blob.Uri.ToString()
            : $"{publicBase.TrimEnd('/')}/{container.Name}/{blobName}";
    }

    private async Task<BlobContainerClient> GetContainerAsync(CancellationToken ct)
    {
        if (_container is not null) return _container;

        await _gate.WaitAsync(ct);
        try
        {
            if (_container is not null) return _container;

            var connectionString = config["AzureBlob:ConnectionString"];
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new BlobStorageNotConfiguredException();

            var containerName = config["AzureBlob:ContainerName"];
            if (string.IsNullOrWhiteSpace(containerName)) containerName = "raceday-images";

            var container = new BlobContainerClient(connectionString, containerName);
            // Public read access for blobs so the browser can display banners and avatars directly.
            await container.CreateIfNotExistsAsync(PublicAccessType.Blob, cancellationToken: ct);

            _container = container;
            return container;
        }
        finally
        {
            _gate.Release();
        }
    }
}
