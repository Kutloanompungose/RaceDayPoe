using System.Text.RegularExpressions;

namespace RaceDay.Web.Services;

/// <summary>Small display helpers shared by views and controllers.</summary>
public static partial class Formatting
{
    /// <summary>1 -> "1st", 2 -> "2nd", 3 -> "3rd", 11 -> "11th", 47 -> "47th".</summary>
    public static string Ordinal(int number)
    {
        var lastTwo = number % 100;
        if (lastTwo is >= 11 and <= 13) return $"{number}th";
        return (number % 10) switch
        {
            1 => $"{number}st",
            2 => $"{number}nd",
            3 => $"{number}rd",
            _ => $"{number}th"
        };
    }

    /// <summary>"47th out of 312 finishers" (falls back gracefully when data is missing).</summary>
    public static string PositionText(int? position, int totalFinishers)
    {
        if (position is null) return "—";
        if (totalFinishers <= 0) return Ordinal(position.Value);
        var noun = totalFinishers == 1 ? "finisher" : "finishers";
        return $"{Ordinal(position.Value)} out of {totalFinishers} {noun}";
    }

    /// <summary>Formats a race time as h:mm:ss (e.g. 1:05:09), or a dash when there is none.</summary>
    public static string Duration(TimeSpan? time)
    {
        if (time is null) return "—";
        var t = time.Value;
        var hours = (int)t.TotalHours;
        return $"{hours}:{t.Minutes:D2}:{t.Seconds:D2}";
    }

    /// <summary>CSS class used for colour-coded status badges (green = Confirmed, amber = Pending ...).</summary>
    public static string StatusClass(string? status) => (status ?? "").ToLowerInvariant() switch
    {
        "confirmed" => "status-confirmed",
        "pending" => "status-pending",
        "cancelled" => "status-cancelled",
        "finished" => "status-finished",
        "dnf" => "status-dnf",
        "dns" => "status-dns",
        _ => "status-default"
    };

    [GeneratedRegex(@"^\d{1,3}:[0-5]\d:[0-5]\d$")]
    private static partial Regex FinishTimePattern();

    /// <summary>Parses "h:mm:ss" / "hh:mm:ss". Returns false for anything else (e.g. "45:30", "abc").</summary>
    public static bool TryParseFinishTime(string? input, out TimeSpan time)
    {
        time = default;
        if (string.IsNullOrWhiteSpace(input)) return false;
        var text = input.Trim();
        if (!FinishTimePattern().IsMatch(text)) return false;

        var parts = text.Split(':');
        time = new TimeSpan(int.Parse(parts[0]), int.Parse(parts[1]), int.Parse(parts[2]));
        return time > TimeSpan.Zero;
    }
}
