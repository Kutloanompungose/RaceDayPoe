namespace RaceDay.Web.Services;

/// <summary>Outcome of a call to the RaceDay API. Controllers never see raw HTTP errors.</summary>
public class ApiResult
{
    public bool Success { get; init; }
    public int StatusCode { get; init; }
    /// <summary>A friendly, user-safe message (never a stack trace or raw response body).</summary>
    public string Message { get; init; } = "";
    public List<string> Errors { get; init; } = new();

    public bool IsUnauthorized => StatusCode == 401;

    public static ApiResult Ok() => new() { Success = true, StatusCode = 200 };

    public static ApiResult Fail(int status, string message, List<string>? errors = null) =>
        new() { Success = false, StatusCode = status, Message = message, Errors = errors ?? new List<string> { message } };
}

public class ApiResult<T> : ApiResult
{
    public T? Data { get; init; }

    public static ApiResult<T> Ok(T? data, int status = 200) =>
        new() { Success = true, StatusCode = status, Data = data };

    public new static ApiResult<T> Fail(int status, string message, List<string>? errors = null) =>
        new() { Success = false, StatusCode = status, Message = message, Errors = errors ?? new List<string> { message } };
}
