using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using RaceDay.Web.Models.Api;

namespace RaceDay.Web.Services;

/// <summary>Everything the MVC app can ask the RaceDay API to do. This is the ONLY way the web app touches data or files.</summary>
public interface IRaceDayApi
{
    // Auth + profile
    Task<ApiResult<UserInfo>> RegisterAsync(RegisterBody body);
    Task<ApiResult<LoginResult>> LoginAsync(LoginBody body);
    Task<ApiResult<UserInfo>> GetMeAsync();
    Task<ApiResult<UserInfo>> UpdateMeAsync(ProfileBody body);
    Task<ApiResult<UserInfo>> UploadProfilePictureAsync(IFormFile file);

    // Events
    Task<ApiResult<List<EventInfo>>> GetUpcomingEventsAsync();
    Task<ApiResult<EventDetail>> GetEventAsync(int id);
    Task<ApiResult<List<EventSummary>>> GetMyEventsAsync();
    Task<ApiResult<EventInfo>> CreateEventAsync(EventBody body);
    Task<ApiResult<EventInfo>> UpdateEventAsync(int id, EventBody body);
    Task<ApiResult> DeleteEventAsync(int id);
    Task<ApiResult<EventInfo>> UploadBannerAsync(int eventId, IFormFile file);
    Task<ApiResult<List<EnrolmentInfo>>> GetEventEnrolmentsAsync(int eventId);

    // Categories
    Task<ApiResult<CategoryInfo>> CreateCategoryAsync(int eventId, CategoryBody body);
    Task<ApiResult<CategoryInfo>> UpdateCategoryAsync(int categoryId, CategoryBody body);
    Task<ApiResult> DeleteCategoryAsync(int categoryId);

    // Enrolments
    Task<ApiResult<EnrolmentInfo>> EnrolAsync(int categoryId);
    Task<ApiResult<List<EnrolmentInfo>>> GetMyEnrolmentsAsync();
    Task<ApiResult> CancelEnrolmentAsync(int enrolmentId);

    // Results
    Task<ApiResult<ResultInfo>> CaptureResultAsync(ResultBody body);
    Task<ApiResult<ResultInfo>> CorrectResultAsync(int resultId, ResultBody body);
    Task<ApiResult<List<ResultInfo>>> GetMyResultsAsync();
    Task<ApiResult<List<ResultInfo>>> GetEventResultsAsync(int eventId);
}

public class RaceDayApi(HttpClient http, ISessionState session, ILogger<RaceDayApi> log) : IRaceDayApi
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    // ---------- auth + profile ----------
    public Task<ApiResult<UserInfo>> RegisterAsync(RegisterBody body) =>
        SendAsync<UserInfo>(HttpMethod.Post, "api/auth/register", Body(body), authorised: false);

    public Task<ApiResult<LoginResult>> LoginAsync(LoginBody body) =>
        SendAsync<LoginResult>(HttpMethod.Post, "api/auth/login", Body(body), authorised: false);

    public Task<ApiResult<UserInfo>> GetMeAsync() => SendAsync<UserInfo>(HttpMethod.Get, "api/users/me");

    public Task<ApiResult<UserInfo>> UpdateMeAsync(ProfileBody body) =>
        SendAsync<UserInfo>(HttpMethod.Put, "api/users/me", Body(body));

    public Task<ApiResult<UserInfo>> UploadProfilePictureAsync(IFormFile file) =>
        SendAsync<UserInfo>(HttpMethod.Post, "api/users/me/picture", FileBody(file));

    // ---------- events ----------
    public Task<ApiResult<List<EventInfo>>> GetUpcomingEventsAsync() =>
        SendAsync<List<EventInfo>>(HttpMethod.Get, "api/events");

    public Task<ApiResult<EventDetail>> GetEventAsync(int id) =>
        SendAsync<EventDetail>(HttpMethod.Get, $"api/events/{id}");

    public Task<ApiResult<List<EventSummary>>> GetMyEventsAsync() =>
        SendAsync<List<EventSummary>>(HttpMethod.Get, "api/events/mine");

    public Task<ApiResult<EventInfo>> CreateEventAsync(EventBody body) =>
        SendAsync<EventInfo>(HttpMethod.Post, "api/events", Body(body));

    public Task<ApiResult<EventInfo>> UpdateEventAsync(int id, EventBody body) =>
        SendAsync<EventInfo>(HttpMethod.Put, $"api/events/{id}", Body(body));

    public async Task<ApiResult> DeleteEventAsync(int id) =>
        await SendAsync<object>(HttpMethod.Delete, $"api/events/{id}");

    public Task<ApiResult<EventInfo>> UploadBannerAsync(int eventId, IFormFile file) =>
        SendAsync<EventInfo>(HttpMethod.Post, $"api/events/{eventId}/banner", FileBody(file));

    public Task<ApiResult<List<EnrolmentInfo>>> GetEventEnrolmentsAsync(int eventId) =>
        SendAsync<List<EnrolmentInfo>>(HttpMethod.Get, $"api/events/{eventId}/enrolments");

    // ---------- categories ----------
    public Task<ApiResult<CategoryInfo>> CreateCategoryAsync(int eventId, CategoryBody body) =>
        SendAsync<CategoryInfo>(HttpMethod.Post, $"api/events/{eventId}/categories", Body(body));

    public Task<ApiResult<CategoryInfo>> UpdateCategoryAsync(int categoryId, CategoryBody body) =>
        SendAsync<CategoryInfo>(HttpMethod.Put, $"api/categories/{categoryId}", Body(body));

    public async Task<ApiResult> DeleteCategoryAsync(int categoryId) =>
        await SendAsync<object>(HttpMethod.Delete, $"api/categories/{categoryId}");

    // ---------- enrolments ----------
    public Task<ApiResult<EnrolmentInfo>> EnrolAsync(int categoryId) =>
        SendAsync<EnrolmentInfo>(HttpMethod.Post, "api/enrolments", Body(new EnrolBody { CategoryId = categoryId }));

    public Task<ApiResult<List<EnrolmentInfo>>> GetMyEnrolmentsAsync() =>
        SendAsync<List<EnrolmentInfo>>(HttpMethod.Get, "api/enrolments/me");

    public async Task<ApiResult> CancelEnrolmentAsync(int enrolmentId) =>
        await SendAsync<object>(HttpMethod.Delete, $"api/enrolments/{enrolmentId}");

    // ---------- results ----------
    public Task<ApiResult<ResultInfo>> CaptureResultAsync(ResultBody body) =>
        SendAsync<ResultInfo>(HttpMethod.Post, "api/results", Body(body));

    public Task<ApiResult<ResultInfo>> CorrectResultAsync(int resultId, ResultBody body) =>
        SendAsync<ResultInfo>(HttpMethod.Put, $"api/results/{resultId}", Body(body));

    public Task<ApiResult<List<ResultInfo>>> GetMyResultsAsync() =>
        SendAsync<List<ResultInfo>>(HttpMethod.Get, "api/results/me");

    public Task<ApiResult<List<ResultInfo>>> GetEventResultsAsync(int eventId) =>
        SendAsync<List<ResultInfo>>(HttpMethod.Get, $"api/events/{eventId}/results");

    // ---------- plumbing ----------
    private static StringContent Body(object value) =>
        new(JsonSerializer.Serialize(value, Json), Encoding.UTF8, "application/json");

    private static MultipartFormDataContent FileBody(IFormFile file)
    {
        var form = new MultipartFormDataContent();
        var part = new StreamContent(file.OpenReadStream());
        part.Headers.ContentType = new MediaTypeHeaderValue(
            string.IsNullOrWhiteSpace(file.ContentType) ? "application/octet-stream" : file.ContentType);
        form.Add(part, "file", file.FileName);
        return form;
    }

    private async Task<ApiResult<T>> SendAsync<T>(HttpMethod method, string url, HttpContent? content = null, bool authorised = true)
    {
        try
        {
            using var request = new HttpRequestMessage(method, url) { Content = content };
            if (authorised && session.Token is { Length: > 0 } token)
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

            using var response = await http.SendAsync(request);
            var text = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                T? data = default;
                if (!string.IsNullOrWhiteSpace(text) && typeof(T) != typeof(object))
                    data = JsonSerializer.Deserialize<T>(text, Json);
                return ApiResult<T>.Ok(data, (int)response.StatusCode);
            }

            return ToFailure<T>(response.StatusCode, text);
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or JsonException)
        {
            log.LogWarning(ex, "Call to RaceDay API failed: {Method} {Url}", method, url);
            return ApiResult<T>.Fail(503, "We can't reach the RaceDay service right now. Please try again in a moment.");
        }
    }

    /// <summary>Turns an API error response into messages that are safe to show to a user.</summary>
    private static ApiResult<T> ToFailure<T>(HttpStatusCode status, string body)
    {
        var errors = new List<string>();
        try
        {
            using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(body) ? "{}" : body);
            var root = doc.RootElement;
            if (root.ValueKind == JsonValueKind.Object)
            {
                if (root.TryGetProperty("errors", out var validation) && validation.ValueKind == JsonValueKind.Object)
                {
                    foreach (var field in validation.EnumerateObject())
                        if (field.Value.ValueKind == JsonValueKind.Array)
                            foreach (var msg in field.Value.EnumerateArray())
                                if (msg.GetString() is { Length: > 0 } m) errors.Add(m);
                }
                else if (root.TryGetProperty("detail", out var detail) && detail.GetString() is { Length: > 0 } d)
                {
                    errors.Add(d);
                }
            }
        }
        catch (JsonException)
        {
            // Not JSON - fall through to the generic message below.
        }

        if (errors.Count == 0) errors.Add(DefaultMessage(status));
        return ApiResult<T>.Fail((int)status, errors[0], errors);
    }

    private static string DefaultMessage(HttpStatusCode status) => status switch
    {
        HttpStatusCode.Unauthorized => "Your session has expired. Please log in again.",
        HttpStatusCode.Forbidden => "You don't have permission to do that.",
        HttpStatusCode.NotFound => "We couldn't find what you were looking for.",
        HttpStatusCode.BadRequest => "Some of the information you entered isn't valid.",
        HttpStatusCode.Conflict => "That conflicts with existing information.",
        _ => "Something went wrong on our side. Please try again."
    };
}
