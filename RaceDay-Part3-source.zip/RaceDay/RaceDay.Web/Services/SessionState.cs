using RaceDay.Web.Models.Api;

namespace RaceDay.Web.Services;

public static class AppRoles
{
    public const string Organiser = "Organiser";
    public const string Participant = "Participant";
}

/// <summary>The signed-in user, kept in server-side session so every page knows who they are and what role they have.</summary>
public interface ISessionState
{
    bool IsAuthenticated { get; }
    string? Token { get; }
    int UserId { get; }
    string FullName { get; }
    string? Role { get; }
    string? ProfilePictureUrl { get; }
    bool IsOrganiser { get; }
    bool IsParticipant { get; }

    void SignIn(LoginResult login);
    void UpdateProfile(UserInfo user);
    void SignOut();
}

public class SessionState(IHttpContextAccessor accessor) : ISessionState
{
    private const string KeyToken = "rd.token";
    private const string KeyExpires = "rd.expires";
    private const string KeyUserId = "rd.userId";
    private const string KeyName = "rd.name";
    private const string KeyRole = "rd.role";
    private const string KeyPicture = "rd.picture";

    private ISession? Session => accessor.HttpContext?.Session;

    public string? Token => Session?.GetString(KeyToken);

    public bool IsAuthenticated
    {
        get
        {
            if (string.IsNullOrEmpty(Token)) return false;
            // The API token and the web session expire together.
            return long.TryParse(Session?.GetString(KeyExpires), out var ticks)
                   && new DateTime(ticks, DateTimeKind.Utc) > DateTime.UtcNow;
        }
    }

    public int UserId => Session?.GetInt32(KeyUserId) ?? 0;
    public string FullName => Session?.GetString(KeyName) ?? "";
    public string? Role => Session?.GetString(KeyRole);
    public string? ProfilePictureUrl => Session?.GetString(KeyPicture);
    public bool IsOrganiser => IsAuthenticated && Role == AppRoles.Organiser;
    public bool IsParticipant => IsAuthenticated && Role == AppRoles.Participant;

    public void SignIn(LoginResult login)
    {
        var s = Session ?? throw new InvalidOperationException("Session is not available.");
        s.Clear();
        s.SetString(KeyToken, login.Token);
        s.SetString(KeyExpires, DateTime.SpecifyKind(login.ExpiresAt, DateTimeKind.Utc).Ticks.ToString());
        s.SetInt32(KeyUserId, login.User.UserID);
        UpdateProfile(login.User);
    }

    public void UpdateProfile(UserInfo user)
    {
        var s = Session;
        if (s is null) return;
        s.SetString(KeyName, user.FullName);
        s.SetString(KeyRole, user.Role);
        s.SetString(KeyPicture, user.ProfilePictureUrl ?? "");
    }

    public void SignOut() => Session?.Clear();
}
