using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Models.Api;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class AccountController(IRaceDayApi api, ISessionState session) : AppController(api, session)
{
    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (Me.IsAuthenticated) return RedirectToRoleHome();
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var result = await Api.LoginAsync(new LoginBody { Email = model.Email.Trim(), Password = model.Password });
        if (!result.Success || result.Data is null)
        {
            ModelState.AddModelError(string.Empty, result.IsUnauthorized
                ? "Incorrect email or password. Please try again."
                : result.Message);
            model.Password = "";
            return View(model);
        }

        Me.SignIn(result.Data);

        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return LocalRedirect(model.ReturnUrl);
        return RedirectToRoleHome();
    }

    [HttpGet]
    public IActionResult Register()
    {
        if (Me.IsAuthenticated) return RedirectToRoleHome();
        return View(new RegisterViewModel());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var registered = await Api.RegisterAsync(new RegisterBody
        {
            FullName = model.FullName.Trim(), Email = model.Email.Trim(), Password = model.Password, Role = model.Role
        });
        if (!registered.Success)
        {
            AddApiErrors(registered);
            model.Password = model.ConfirmPassword = "";
            return View(model);
        }

        // Sign the new user straight in so they can start using RaceDay.
        var login = await Api.LoginAsync(new LoginBody { Email = model.Email.Trim(), Password = model.Password });
        if (!login.Success || login.Data is null)
        {
            FlashSuccess("Your account has been created. Please log in.");
            return RedirectToAction(nameof(Login));
        }

        Me.SignIn(login.Data);
        FlashSuccess($"Welcome to RaceDay, {login.Data.User.FullName}!");
        return RedirectToRoleHome();
    }

    /// <summary>Ends the session and returns to the login page.</summary>
    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Logout()
    {
        Me.SignOut();
        TempData["Success"] = "You have been logged out. See you at the start line!";
        return RedirectToAction(nameof(Login));
    }

    public IActionResult AccessDenied() => View();
}
