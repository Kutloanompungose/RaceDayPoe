using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Models.Api;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[SessionAuthorize(AppRoles.Participant)]
public class ParticipantController(IRaceDayApi api, ISessionState session) : AppController(api, session)
{
    // ===================== Browse events (participant home) =====================
    public async Task<IActionResult> Events(EventFilter filter)
    {
        var events = await Api.GetUpcomingEventsAsync();
        if (RedirectIfSessionExpired(events) is { } expired) return expired;
        if (!events.Success) FlashError(events.Message);

        var all = events.Data ?? new List<EventInfo>();

        // Filtering is presentation only: it narrows the list the API already returned.
        IEnumerable<EventInfo> query = all;
        if (!string.IsNullOrWhiteSpace(filter.Search))
        {
            var term = filter.Search.Trim();
            query = query.Where(e => e.Name.Contains(term, StringComparison.OrdinalIgnoreCase)
                                     || e.Venue.Contains(term, StringComparison.OrdinalIgnoreCase));
        }
        if (!string.IsNullOrWhiteSpace(filter.EventType))
            query = query.Where(e => e.EventType == filter.EventType);
        if (!string.IsNullOrWhiteSpace(filter.Province))
            query = query.Where(e => e.Province == filter.Province);
        if (filter.From is { } fromDate)
            query = query.Where(e => e.EventDate.Date >= fromDate.Date);
        if (filter.To is { } toDate)
            query = query.Where(e => e.EventDate.Date <= toDate.Date);

        var mine = await Api.GetMyEnrolmentsAsync();

        return View(new BrowseEventsViewModel
        {
            Filter = filter,
            Events = query.OrderBy(e => e.EventDate).ToList(),
            TotalUpcoming = all.Count,
            EnrolledEventIds = (mine.Data ?? new List<EnrolmentInfo>())
                .Where(e => e.Status != "Cancelled").Select(e => e.EventID).ToHashSet()
        });
    }

    // ===================== Event details + enrol =====================
    public async Task<IActionResult> EventDetails(int id)
    {
        var ev = await Api.GetEventAsync(id);
        if (RedirectIfSessionExpired(ev) is { } expired) return expired;
        if (!ev.Success || ev.Data is null)
        {
            FlashError(ev.StatusCode == 404 ? "That event could not be found." : ev.Message);
            return RedirectToAction(nameof(Events));
        }

        var mine = await Api.GetMyEnrolmentsAsync();
        var enrolledCategories = (mine.Data ?? new List<EnrolmentInfo>())
            .Where(e => e.EventID == id && e.Status != "Cancelled")
            .Select(e => e.CategoryID).ToHashSet();

        return View(new EventDetailsViewModel { Event = ev.Data, EnrolledCategoryIds = enrolledCategories });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Enrol(int eventId, int categoryId)
    {
        if (categoryId <= 0)
        {
            FlashError("Please choose a category to enter.");
            return RedirectToAction(nameof(EventDetails), new { id = eventId });
        }

        var result = await Api.EnrolAsync(categoryId);
        if (RedirectIfSessionExpired(result) is { } expired) return expired;

        if (!result.Success)
        {
            FlashError(result.Message);
            return RedirectToAction(nameof(EventDetails), new { id = eventId });
        }

        FlashSuccess($"You're in! Your race number is {result.Data?.RaceNumber}.");
        return RedirectToAction(nameof(MyEnrolments));
    }

    // ===================== My enrolments =====================
    public async Task<IActionResult> MyEnrolments()
    {
        var result = await Api.GetMyEnrolmentsAsync();
        if (RedirectIfSessionExpired(result) is { } expired) return expired;
        if (!result.Success) FlashError(result.Message);

        return View(result.Data ?? new List<EnrolmentInfo>());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> CancelEnrolment(int id)
    {
        var result = await Api.CancelEnrolmentAsync(id);
        if (RedirectIfSessionExpired(result) is { } expired) return expired;

        if (result.Success) FlashSuccess("Your enrolment has been cancelled.");
        else FlashError(result.Message);
        return RedirectToAction(nameof(MyEnrolments));
    }

    // ===================== My results =====================
    public async Task<IActionResult> MyResults()
    {
        var result = await Api.GetMyResultsAsync();
        if (RedirectIfSessionExpired(result) is { } expired) return expired;
        if (!result.Success) FlashError(result.Message);

        var list = (result.Data ?? new List<ResultInfo>()).OrderByDescending(r => r.EventDate).ToList();
        return View(list);
    }

    // ===================== Profile =====================
    [HttpGet]
    public async Task<IActionResult> Profile()
    {
        var result = await Api.GetMeAsync();
        if (RedirectIfSessionExpired(result) is { } expired) return expired;
        if (!result.Success || result.Data is null)
        {
            FlashError(result.Message);
            return RedirectToAction(nameof(Events));
        }

        return View(ToViewModel(result.Data));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(ProfileViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var result = await Api.UpdateMeAsync(new ProfileBody
        {
            FullName = model.FullName.Trim(),
            Phone = string.IsNullOrWhiteSpace(model.Phone) ? null : model.Phone.Trim()
        });
        if (RedirectIfSessionExpired(result) is { } expired) return expired;

        if (!result.Success || result.Data is null)
        {
            AddApiErrors(result);
            return View(model);
        }

        Me.UpdateProfile(result.Data);
        FlashSuccess("Your profile has been updated.");
        return RedirectToAction(nameof(Profile));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> UploadPicture(IFormFile? picture)
    {
        if (picture is null || picture.Length == 0)
        {
            FlashError("Please choose an image to upload.");
            return RedirectToAction(nameof(Profile));
        }

        var result = await Api.UploadProfilePictureAsync(picture);
        if (RedirectIfSessionExpired(result) is { } expired) return expired;

        if (result.Success && result.Data is not null)
        {
            Me.UpdateProfile(result.Data);
            FlashSuccess("Profile picture updated.");
        }
        else
        {
            FlashError(result.Message);
        }
        return RedirectToAction(nameof(Profile));
    }

    private static ProfileViewModel ToViewModel(UserInfo user) => new()
    {
        FullName = user.FullName, Email = user.Email, Phone = user.Phone, ProfilePictureUrl = user.ProfilePictureUrl
    };
}
