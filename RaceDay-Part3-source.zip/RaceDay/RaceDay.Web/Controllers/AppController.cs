using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

/// <summary>Shared behaviour: access to the API + session, flash messages and role-aware redirects.</summary>
[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)] // protected pages are never cached (back button after logout)
public abstract class AppController(IRaceDayApi api, ISessionState session) : Controller
{
    protected IRaceDayApi Api => api;
    protected ISessionState Me => session;

    protected void FlashSuccess(string message) => TempData["Success"] = message;
    protected void FlashError(string message) => TempData["Error"] = message;
    protected void FlashWarning(string message) => TempData["Warning"] = message;

    protected IActionResult RedirectToRoleHome() =>
        Me.IsOrganiser ? RedirectToAction("Dashboard", "Organiser")
        : Me.IsParticipant ? RedirectToAction("Events", "Participant")
        : RedirectToAction("Login", "Account");

    /// <summary>If the API says the token is no longer valid, end the session and send the user to log in again.</summary>
    protected IActionResult? RedirectIfSessionExpired(ApiResult result)
    {
        if (!result.IsUnauthorized) return null;
        Me.SignOut();
        FlashError("Your session has expired. Please log in again.");
        return RedirectToAction("Login", "Account");
    }

    protected void AddApiErrors(ApiResult result)
    {
        foreach (var error in result.Errors) ModelState.AddModelError(string.Empty, error);
    }
}
