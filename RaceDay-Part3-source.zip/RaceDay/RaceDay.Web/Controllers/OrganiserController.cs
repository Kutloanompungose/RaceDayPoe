using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Models.Api;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[SessionAuthorize(AppRoles.Organiser)]
public class OrganiserController(IRaceDayApi api, ISessionState session) : AppController(api, session)
{
    // ===================== Dashboard =====================
    public async Task<IActionResult> Dashboard()
    {
        var result = await Api.GetMyEventsAsync();
        if (RedirectIfSessionExpired(result) is { } expired) return expired;

        if (!result.Success) FlashError(result.Message);
        return View(new DashboardViewModel { Events = result.Data ?? new List<EventSummary>() });
    }

    // ===================== Events =====================
    public async Task<IActionResult> Events()
    {
        var result = await Api.GetMyEventsAsync();
        if (RedirectIfSessionExpired(result) is { } expired) return expired;

        if (!result.Success) FlashError(result.Message);
        return View(result.Data ?? new List<EventSummary>());
    }

    [HttpGet]
    public IActionResult CreateEvent() => View("EventForm", new EventFormViewModel());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateEvent(EventFormViewModel model)
    {
        if (!ModelState.IsValid) return View("EventForm", model);

        var created = await Api.CreateEventAsync(model.ToBody());
        if (RedirectIfSessionExpired(created) is { } expired) return expired;
        if (!created.Success || created.Data is null)
        {
            AddApiErrors(created);
            return View("EventForm", model);
        }

        // The banner goes to the API, which stores it in Azure Blob Storage.
        if (model.Banner is { Length: > 0 })
        {
            var upload = await Api.UploadBannerAsync(created.Data.EventID, model.Banner);
            if (!upload.Success)
            {
                FlashWarning($"Event created, but the banner could not be uploaded: {upload.Message} You can try again by editing the event.");
                return RedirectToAction(nameof(Categories), new { eventId = created.Data.EventID });
            }
        }

        FlashSuccess("Event created. Now add the categories participants can enter.");
        return RedirectToAction(nameof(Categories), new { eventId = created.Data.EventID });
    }

    [HttpGet]
    public async Task<IActionResult> EditEvent(int id)
    {
        var result = await Api.GetEventAsync(id);
        if (RedirectIfSessionExpired(result) is { } expired) return expired;
        if (!result.Success || result.Data is null) return EventNotAvailable(result);
        if (result.Data.OrganiserID != Me.UserId) return NotYourEvent();

        return View("EventForm", EventFormViewModel.From(result.Data));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> EditEvent(int id, EventFormViewModel model)
    {
        model.EventID = id;
        if (!ModelState.IsValid) return View("EventForm", model);

        var updated = await Api.UpdateEventAsync(id, model.ToBody());
        if (RedirectIfSessionExpired(updated) is { } expired) return expired;
        if (!updated.Success)
        {
            AddApiErrors(updated);
            return View("EventForm", model);
        }

        if (model.Banner is { Length: > 0 })
        {
            var upload = await Api.UploadBannerAsync(id, model.Banner);
            if (!upload.Success)
            {
                AddApiErrors(upload);
                model.ExistingBannerUrl = updated.Data?.BannerUrl;
                FlashWarning("Your changes were saved, but the banner could not be uploaded.");
                return View("EventForm", model);
            }
        }

        FlashSuccess("Event updated.");
        return RedirectToAction(nameof(Events));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var result = await Api.DeleteEventAsync(id);
        if (RedirectIfSessionExpired(result) is { } expired) return expired;

        if (result.Success) FlashSuccess("Event deleted.");
        else FlashError(result.Message);
        return RedirectToAction(nameof(Events));
    }

    // ===================== Categories =====================
    [HttpGet]
    public async Task<IActionResult> Categories(int eventId)
    {
        var ev = await Api.GetEventAsync(eventId);
        if (RedirectIfSessionExpired(ev) is { } expired) return expired;
        if (!ev.Success || ev.Data is null) return EventNotAvailable(ev);
        if (ev.Data.OrganiserID != Me.UserId) return NotYourEvent();

        return View(new CategoriesViewModel { Event = ev.Data, Form = new CategoryFormViewModel { EventID = eventId } });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddCategory(int eventId, CategoryFormViewModel form)
    {
        if (ModelState.IsValid)
        {
            var created = await Api.CreateCategoryAsync(eventId, form.ToBody());
            if (RedirectIfSessionExpired(created) is { } expired) return expired;
            if (created.Success)
            {
                FlashSuccess($"Category “{form.Name.Trim()}” added.");
                return RedirectToAction(nameof(Categories), new { eventId });
            }
            AddApiErrors(created);
        }

        // Validation failed: show the page again with the user's input and the messages.
        var ev = await Api.GetEventAsync(eventId);
        if (RedirectIfSessionExpired(ev) is { } expiredAgain) return expiredAgain;
        if (!ev.Success || ev.Data is null) return EventNotAvailable(ev);

        form.EventID = eventId;
        return View("Categories", new CategoriesViewModel { Event = ev.Data, Form = form });
    }

    [HttpGet]
    public async Task<IActionResult> EditCategory(int eventId, int id)
    {
        var ev = await Api.GetEventAsync(eventId);
        if (RedirectIfSessionExpired(ev) is { } expired) return expired;
        if (!ev.Success || ev.Data is null) return EventNotAvailable(ev);
        if (ev.Data.OrganiserID != Me.UserId) return NotYourEvent();

        var category = ev.Data.Categories.FirstOrDefault(c => c.CategoryID == id);
        if (category is null)
        {
            FlashError("That category no longer exists.");
            return RedirectToAction(nameof(Categories), new { eventId });
        }

        ViewData["EventName"] = ev.Data.Name;
        return View(new CategoryFormViewModel
        {
            CategoryID = category.CategoryID, EventID = eventId, Name = category.Name,
            DistanceKm = category.DistanceKm, MaxParticipants = category.MaxParticipants, EntryFee = category.EntryFee
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> EditCategory(int eventId, int id, CategoryFormViewModel form)
    {
        form.EventID = eventId;
        form.CategoryID = id;
        if (ModelState.IsValid)
        {
            var updated = await Api.UpdateCategoryAsync(id, form.ToBody());
            if (RedirectIfSessionExpired(updated) is { } expired) return expired;
            if (updated.Success)
            {
                FlashSuccess("Category updated.");
                return RedirectToAction(nameof(Categories), new { eventId });
            }
            AddApiErrors(updated);
        }

        return View(form);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteCategory(int eventId, int id)
    {
        var result = await Api.DeleteCategoryAsync(id);
        if (RedirectIfSessionExpired(result) is { } expired) return expired;

        if (result.Success) FlashSuccess("Category deleted.");
        else FlashError(result.Message);
        return RedirectToAction(nameof(Categories), new { eventId });
    }

    // ===================== Enrolments =====================
    public async Task<IActionResult> Enrolments(int eventId)
    {
        var ev = await Api.GetEventAsync(eventId);
        if (RedirectIfSessionExpired(ev) is { } expired) return expired;
        if (!ev.Success || ev.Data is null) return EventNotAvailable(ev);
        if (ev.Data.OrganiserID != Me.UserId) return NotYourEvent();

        var enrolments = await Api.GetEventEnrolmentsAsync(eventId);
        if (!enrolments.Success) FlashError(enrolments.Message);

        return View(new EnrolmentsViewModel { Event = ev.Data, Enrolments = enrolments.Data ?? new List<EnrolmentInfo>() });
    }

    // ===================== Results =====================
    [HttpGet]
    public async Task<IActionResult> Results(int eventId)
    {
        var vm = await BuildResultsAsync(eventId);
        if (vm.Redirect is not null) return vm.Redirect;
        return View(vm.Model);
    }

    /// <summary>Captures a new result, or corrects an existing one, for a single enrolment. Saved results are visible to the participant straight away.</summary>
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveResult(int eventId, int enrolmentId, int? resultId, string status, string? finishTime, int? position)
    {
        var back = Url.Action(nameof(Results), new { eventId }) + $"#row-{enrolmentId}";

        TimeSpan? parsedTime = null;
        if (!string.IsNullOrWhiteSpace(finishTime))
        {
            if (!Formatting.TryParseFinishTime(finishTime, out var time))
            {
                FlashError("Finish time must look like 1:05:09 (hours:minutes:seconds) and be greater than zero.");
                return Redirect(back);
            }
            parsedTime = time;
        }

        if (status == "Finished" && parsedTime is null)
        {
            FlashError("A finisher needs a finish time, e.g. 0:48:30.");
            return Redirect(back);
        }

        if (position is < 1)
        {
            FlashError("Finishing position must be 1 or higher.");
            return Redirect(back);
        }

        var body = new ResultBody
        {
            EnrolmentId = resultId is null ? enrolmentId : null,
            FinishTime = status == "Finished" ? parsedTime : null,   // DNF / DNS have no time or position
            Position = status == "Finished" ? position : null,
            Status = status
        };

        var saved = resultId is { } existing
            ? await Api.CorrectResultAsync(existing, body)
            : await Api.CaptureResultAsync(body);
        if (RedirectIfSessionExpired(saved) is { } expired) return expired;

        if (saved.Success) FlashSuccess("Result saved and published to the participant.");
        else FlashError(saved.Message);
        return Redirect(back);
    }

    private async Task<(ResultsViewModel? Model, IActionResult? Redirect)> BuildResultsAsync(int eventId)
    {
        var ev = await Api.GetEventAsync(eventId);
        if (RedirectIfSessionExpired(ev) is { } expired) return (null, expired);
        if (!ev.Success || ev.Data is null) return (null, EventNotAvailable(ev));
        if (ev.Data.OrganiserID != Me.UserId) return (null, NotYourEvent());

        var enrolments = await Api.GetEventEnrolmentsAsync(eventId);
        var results = await Api.GetEventResultsAsync(eventId);
        if (!enrolments.Success) FlashError(enrolments.Message);

        var byEnrolment = (results.Data ?? new List<ResultInfo>()).ToDictionary(r => r.EnrolmentID);
        var rows = (enrolments.Data ?? new List<EnrolmentInfo>())
            .Where(e => e.Status != "Cancelled")
            .OrderBy(e => e.CategoryName).ThenBy(e => e.ParticipantName)
            .Select(e => new ResultRow { Enrolment = e, Result = byEnrolment.GetValueOrDefault(e.EnrolmentID) })
            .ToList();

        return (new ResultsViewModel { Event = ev.Data, Rows = rows }, null);
    }

    // ===================== helpers =====================
    private IActionResult EventNotAvailable(ApiResult result)
    {
        if (result.StatusCode == 404) FlashError("That event no longer exists.");
        else FlashError(result.Message);
        return RedirectToAction(nameof(Events));
    }

    private IActionResult NotYourEvent()
    {
        FlashError("You can only manage events that you created.");
        return RedirectToAction(nameof(Events));
    }
}
