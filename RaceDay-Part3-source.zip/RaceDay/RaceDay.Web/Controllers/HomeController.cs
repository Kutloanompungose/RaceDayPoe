using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class HomeController(IRaceDayApi api, ISessionState session) : AppController(api, session)
{
    /// <summary>Public landing page for visitors; signed-in users go straight to their own home.</summary>
    public IActionResult Index() => Me.IsAuthenticated ? RedirectToRoleHome() : View();

    public IActionResult Error() => View();

    public IActionResult HttpStatus(int code)
    {
        ViewData["Code"] = code;
        return View();
    }
}
