// RaceDay - small progressive enhancements. The site still works without JavaScript.
(function () {
  "use strict";

  // Confirm before destructive actions: <form data-confirm="Delete this event?">
  document.querySelectorAll("form[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (!window.confirm(form.getAttribute("data-confirm"))) e.preventDefault();
    });
  });

  // Live preview for image pickers: <input type="file" data-preview="#imgId">
  document.querySelectorAll("input[type=file][data-preview]").forEach(function (input) {
    input.addEventListener("change", function () {
      var target = document.querySelector(input.getAttribute("data-preview"));
      if (!target || !input.files || !input.files[0]) return;
      var file = input.files[0];
      if (file.size > 5 * 1024 * 1024) {
        window.alert("That image is larger than 5 MB. Please choose a smaller one.");
        input.value = "";
        return;
      }
      target.src = URL.createObjectURL(file);
      target.classList.remove("d-none");
    });
  });

  // Stop double submits.
  document.querySelectorAll("form").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (e.defaultPrevented) return;
      var btn = form.querySelector("button[type=submit][data-busy]");
      if (btn) { btn.disabled = true; btn.textContent = btn.getAttribute("data-busy"); }
    });
  });
})();
