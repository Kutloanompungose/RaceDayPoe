using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.Tests;

public class ImageUploadTests(ApiFactory factory) : ApiTestBase(factory)
{
    private static MultipartFormDataContent ImageForm(string fileName, int sizeBytes = 64)
    {
        var form = new MultipartFormDataContent();
        var file = new ByteArrayContent(new byte[sizeBytes]);
        file.Headers.ContentType = new MediaTypeHeaderValue("image/png");
        form.Add(file, "file", fileName);
        return form;
    }

    [Fact]
    public async Task Organiser_CanUploadBanner_ForOwnEvent()
    {
        var organiser = await LoginAs("Organiser");
        var eventId = await CreateEvent(organiser);

        var res = await organiser.PostAsync($"/api/events/{eventId}/banner", ImageForm("banner.png"));

        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        var json = await res.Content.ReadFromJsonAsync<JsonElement>();
        Assert.Contains("banner.png", json.GetProperty("bannerUrl").GetString());
    }

    [Fact]
    public async Task Organiser_CannotUploadBanner_ForSomeoneElsesEvent()
    {
        var owner = await LoginAs("Organiser");
        var other = await LoginAs("Organiser");
        var eventId = await CreateEvent(owner);

        var res = await other.PostAsync($"/api/events/{eventId}/banner", ImageForm("banner.png"));

        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }

    [Fact]
    public async Task UploadBanner_WithNonImageFile_Returns400()
    {
        var organiser = await LoginAs("Organiser");
        var eventId = await CreateEvent(organiser);

        var res = await organiser.PostAsync($"/api/events/{eventId}/banner", ImageForm("malware.exe"));

        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }

    [Fact]
    public async Task UploadBanner_AsParticipant_Returns403()
    {
        var organiser = await LoginAs("Organiser");
        var participant = await LoginAs("Participant");
        var eventId = await CreateEvent(organiser);

        var res = await participant.PostAsync($"/api/events/{eventId}/banner", ImageForm("banner.png"));

        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }

    [Fact]
    public async Task User_CanUploadProfilePicture()
    {
        var participant = await LoginAs("Participant");

        var res = await participant.PostAsync("/api/users/me/picture", ImageForm("me.jpg"));

        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        var json = await res.Content.ReadFromJsonAsync<JsonElement>();
        Assert.Contains("me.jpg", json.GetProperty("profilePictureUrl").GetString());
    }

    [Fact]
    public async Task Organiser_EventsMine_ReturnsOnlyOwnEvents_WithEnrolmentCount()
    {
        var organiser = await LoginAs("Organiser");
        var other = await LoginAs("Organiser");
        var participant = await LoginAs("Participant");

        var eventId = await CreateEvent(organiser);
        var categoryId = await CreateCategory(organiser, eventId);
        await CreateEvent(other);
        await Enrol(participant, categoryId);

        var res = await organiser.GetAsync("/api/events/mine");

        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        var list = await res.Content.ReadFromJsonAsync<JsonElement>();
        Assert.Equal(1, list.GetArrayLength());
        Assert.Equal(1, list[0].GetProperty("enrolmentCount").GetInt32());
    }

    [Fact]
    public async Task Participant_EventsMine_Returns403()
    {
        var participant = await LoginAs("Participant");
        var res = await participant.GetAsync("/api/events/mine");
        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }
}
